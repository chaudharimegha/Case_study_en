﻿using System.ComponentModel.DataAnnotations;

namespace Railway_Reservationsystem_WebAPI.Models
{
    public class Admin
    {
        [Key]
        // public int Id { get; set; }
        public string? Name { get; set; }
        public string? Password { get; set; }
    }
}
