﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Railway_Reservationsystem_WebAPI.Data;
using Railway_Reservationsystem_WebAPI.Models;

//Train Details Controller
namespace Railway_Reservationsystem_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainDetailsController : ControllerBase
    {
        //DB Context
        private readonly LoginDbContext _context;
        public TrainDetailsController(LoginDbContext loginDbContext)
        {
            _context = loginDbContext;

        }

        //Post Method
        [HttpPost("add_train")]
        public IActionResult AddTrain([FromBody] TrainDetails trainObj)
        {
            if (trainObj == null)
            {
                return BadRequest();
            }
            else
            {
                _context.TrainDetailsModels.Add(trainObj);
                _context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "Train Added Successfully"
                }
                    );
            }
        }

        //get method
        [HttpGet("TrainDetails")]
        public IActionResult GetUsers()
        {
            //getting details from TrainDetailsModels As a List 
            var userdetails = _context.TrainDetailsModels.AsQueryable();
            //returning data fetched via above query
            return Ok(new
            {
                StatusCode = 200,
                TrainDetails = userdetails //returning object

            });
        }
        //Get train_by id
        [HttpGet("TrainDetails_by_id")]
        public IActionResult GetUsers_Byid(string SourceStation, string DestinationStation)
        {

            var userdeatils = _context.TrainDetailsModels.FirstOrDefault(
                TrainDetails => TrainDetails.SourceStation == SourceStation
                && TrainDetails.DestinationStation == DestinationStation);
            // var userdeatil = _context.TrainDetailsModels.Find(Destination);
            if (userdeatils == null)
            {
                return NotFound(new
                {
                    StatusCode = 404,
                    Message = "Train Not Found"
                });
            }
            else
            {
                var Traindetails = _context.TrainDetailsModels.Where(
                    search => search.SourceStation == SourceStation && search.DestinationStation == DestinationStation).ToList();
                if (Traindetails != null)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        TrainDetails = Traindetails //returning object

                    });
                }
            }

            return Ok();
        }
        //Update the Train
        [HttpPut("update_train")]
        public IActionResult UpdateTrain([FromBody] TrainDetails trainObj)
        {
            if (trainObj == null)
            {
                return BadRequest();
            }
            var train = _context.TrainDetailsModels.AsNoTracking().FirstOrDefault(x => x.TrainId == trainObj.TrainId);
            if (train == null)
            {
                return NotFound(new
                {
                    StatusCode = 404,
                    Message ="Train Not Found"
                });
            }
            else
            {
                _context.Entry(trainObj).State= EntityState.Modified;
                _context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "Train Updated Successfully"
                });
            }
        }
        //Delete Method
        [HttpDelete("Delete_train_id")]
        public IActionResult DeleteTrain(int train_id)
        {
            var train = _context.TrainDetailsModels.Find(train_id);
            if (train == null)
            {
                return NotFound(new
                {
                    StatusCode = 404,
                    Message = "Train Not found"
                });

            }
            else 
            {
                _context.Remove(train);
                _context.SaveChanges();
                return Ok(new
                {
                    StatusCode = 200,
                    Message = "Train Deleted"
                });
            }
        }





        //post method
    /*    [HttpPost("getTrainDetails")]
        public IActionResult getTrainDetails([FromBody] TrainDetails obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                var trainObj = _context.TrainDetailsModels.Where(a =>
                a.SourceStation == obj.SourceStation
                && a.DestinationStation == obj.DestinationStation).FirstOrDefault();
                if (trainObj != null)
                {
                    //Return object if train found
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = "Train found",
                        TrainInfo = trainObj
                    });
                }
                else
                {
                    //Return object if train not found
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "Train not found for this route"
                    });
                }

            }
        }*/

    }
}
